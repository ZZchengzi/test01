package demo14;

/*
枚举就是几个固定常量
 */
public enum Direction
{
    UP,DOWN,LEFT,RIGHT
}
